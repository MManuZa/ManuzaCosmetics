agrega cositas mias xd.

# COSMETIC LIST:

### HATS:
- ManuZa plushie
- ManuZita owo